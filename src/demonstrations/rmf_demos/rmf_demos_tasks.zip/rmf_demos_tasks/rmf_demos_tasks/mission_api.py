# =============================================================================
# RMF Mission API - FastAPI Server for WCS Integration
# =============================================================================
# This module provides a REST API that bridges WCS (Warehouse Control System)
# with RMF (Robot Management Framework) for creating and monitoring loop missions.
# 
# Key Features:
# - POST /api/MissionCreate: Create new loop missions from WCS
# - GET /api/GetMissions: Get real-time status of all missions
# - Real-time mission tracking via ROS 2 topics
# - Automatic robot assignment and status updates
# - API key authentication for security
# - Professional robot assignment synchronization with RMF
# - Loop tasks with pickup/dropoff locations and priority support
# =============================================================================

from fastapi import FastAPI, Request, HTTPException, Header
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import json
import logging
import asyncio
import uuid
import os
from datetime import datetime
from collections import defaultdict

# ROS 2 imports for RMF integration
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSDurabilityPolicy as Durability
from rclpy.qos import QoSHistoryPolicy as History
from rclpy.qos import QoSProfile
from rclpy.qos import QoSReliabilityPolicy as Reliability
from rmf_task_msgs.msg import ApiRequest, ApiResponse
from rmf_task_msgs.srv import SubmitTask
from rmf_task_msgs.msg import TaskType, Loop
from rmf_fleet_msgs.msg import FleetState

# Configure logging for debugging and monitoring
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Fixed handlers for loop operations
# These are predefined handlers that RMF uses for loop operations
LOOP_DEFAULT_ROUNDS = 1       # Default number of loop rounds

# =============================================================================
# API AUTHENTICATION CONFIGURATION
# =============================================================================

# API key for WCS authentication
# In production, set this via environment variable: export WCS_API_KEY="123456789"
WCS_API_KEY = os.getenv("WCS_API_KEY", "123456789")
API_KEY_HEADER = "Apikey"

# Initialize FastAPI application
app = FastAPI(title="RMF Mission API", version="1.0.0")

@app.on_event("startup")
async def startup_event():
    """Initialize the mission API when FastAPI starts"""
    logger.info("🚀 Starting RMF Mission API...")
    
    # Start background ROS 2 monitoring
    await start_background_monitoring()
    logger.info("✅ Background ROS 2 monitoring started")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup when FastAPI shuts down"""
    logger.info("🛑 Shutting down RMF Mission API...")
    
    # Stop background monitoring
    global background_task
    if background_task:
        background_task.cancel()
        try:
            await background_task
        except asyncio.CancelledError:
            pass
        logger.info("✅ Background ROS 2 monitoring stopped")
    
    # Shutdown ROS 2
    try:
        rclpy.shutdown()
        logger.info("✅ ROS 2 shutdown completed")
    except Exception as e:
        logger.warning(f"ROS 2 shutdown warning: {e}")

# =============================================================================
# GLOBAL DATA STORAGE
# =============================================================================

# In-memory database to store mission information
# In production, this should be replaced with a proper database
missions_db = {}  # Store mission data with mission_id as key
mission_counter = 100  # Start mission IDs from 100 to avoid conflicts

# ROS 2 context management
ros_context_initialized = False

# Mapping between RMF place names and numerical IDs for WCS compatibility
# WCS expects numerical IDs, but RMF uses place names like "R1", "R7"
TARGET_ID_MAP = {
    "R1": 1, "R2": 2, "R3": 3, "R4": 4, "R5": 5, "R6": 6, "R7": 7,
    "R9": 9, "R10": 10, "R11": 11, "R21": 21, "R22": 22, "R23": 23,
    "R24": 24, "R25": 25, "R26": 26, "R27": 27, "R28": 28, "R29": 29
}

# Reverse mapping for converting IDs back to place names
TARGET_ID_REVERSE_MAP = {v: k for k, v in TARGET_ID_MAP.items()}

# =============================================================================
# PYDANTIC MODELS FOR REQUEST/RESPONSE VALIDATION
# =============================================================================

class LoadOptions(BaseModel):
    """Model for load requirements in mission steps"""
    RequiredLoadStatus: str    # e.g., "LoadAtLocation", "LocationHasRoom"
    RequiredLoadType: int      # Load type identifier

class StepOptions(BaseModel):
    """Model for step configuration options"""
    Load: LoadOptions
    SortingRules: Optional[List[str]] = None  # e.g., ["Priority", "Closest"]

class Target(BaseModel):
    """Model for target locations in mission steps"""
    Id: str  # Place name like "R1", "R7" (changed from int to str for direct RMF integration)

class Step(BaseModel):
    """Model for individual mission steps (Pickup/Dropoff for WCS compatibility)"""
    StepType: str              # "Pickup" or "Dropoff" for WCS compatibility
    Options: StepOptions       # Step configuration
    AllowedTargets: List[Target]  # Valid target locations
    AllowedWaits: Optional[List[Any]] = None

class MissionOptions(BaseModel):
    """Model for mission-level configuration"""
    Priority: int              # Mission priority level
    Rounds: Optional[int] = 1  # Number of patrol rounds

class MissionRequest(BaseModel):
    """Model for incoming mission creation requests from WCS"""
    ExternalId: str            # WCS-provided mission identifier
    Name: str                  # Mission name/description
    Options: MissionOptions    # Mission configuration
    Steps: List[Step]         # List of patrol steps

class MissionResponse(BaseModel):
    """Model for mission creation response to WCS"""
    ExternalId: str            # Original WCS mission ID
    InternalId: int            # Internal mission ID (our system)
    Success: bool              # Whether mission creation succeeded
    Description: str           # Success/error description
    ReplyResult: str           # Result code for WCS processing

# =============================================================================
# GET MISSIONS RESPONSE MODELS
# =============================================================================

class StepData(BaseModel):
    """Model for step information in GetMissions response"""
    StepType: str              # "Pickup" or "Dropoff" for WCS compatibility
    StepStatus: str            # "Generated", "DrivingToPickup", "DrivingToDropoff", "Complete"
    CurrentTarget: str         # Human-readable target description
    CurrentTargetId: int       # Numerical target ID for WCS
    WaitTarget: str            # Target to wait at (if any)
    TargetShelfId: int         # Shelf ID (-1 if not applicable)
    LoadType: str              # Type of load being transported
    LoadTypeId: int            # Load type identifier
    ReservingLocation: bool    # Whether location is being reserved

class MissionData(BaseModel):
    """Model for mission information in GetMissions response"""
    Id: int                    # Internal mission ID
    MissionType: str           # Always "Mission"
    ExternalId: str            # WCS mission ID
    Name: str                  # Mission name
    State: str                 # "Generated", "Executing", "Complete", "Failed", "Cancelled"
    AssignedMachine: str       # Robot name (e.g., "FourD_robot_3")
    AssignedMachineId: int     # Robot ID (1, 2, 3, etc.)
    CurrentStepIndex: int      # Current step being executed
    FinalTarget: str           # Human-readable final destination
    FinalTargetId: int         # Numerical ID of final destination
    Steps: List[StepData]      # List of mission steps with status

# =============================================================================
# ROS 2 NODE CLASSES FOR RMF INTEGRATION
# =============================================================================

class MissionTracker(Node):
    """
    Mission Tracker Node - Monitors fleet states and manages mission lifecycle
    
    This is a singleton node that continuously monitors RMF fleet states
    and updates mission status in real-time. It follows ROS 2 best practices
    for persistent node management and ensures perfect synchronization with RMF.
    """
    
    def __init__(self):
        """Initialize the mission tracker node"""
        super().__init__('mission_tracker')
        
        # Subscribe to fleet states for robot-level status updates
        self.fleet_state_sub = self.create_subscription(
            FleetState, 'fleet_states', self.fleet_state_callback, 10
        )
        
        # Store fleet state data for status tracking
        self.fleet_states = {}     # Fleet name -> fleet info
        self.previous_task_ids = {}  # Robot name -> previous task_id for completion detection
        
        # Timer will be created later when the node is properly running
        self.update_timer = None
        
        logger.info("Mission tracker initialized")
    
    def start_timer(self):
        """Start the update timer - called when node is properly running"""
        if self.update_timer is None:
            try:
                self.update_timer = self.create_timer(1.0, self.update_mission_status)
                logger.info("✅ Mission tracker timer started")
            except Exception as e:
                logger.error(f"Failed to create timer: {e}")
                raise
    
    def fleet_state_callback(self, msg: FleetState):
        """
        Handle fleet state updates from RMF
        
        Args:
            msg: Fleet state message from RMF
        """
        try:
            fleet_name = msg.name
            
            # Store fleet state data
            self.fleet_states[fleet_name] = {
                'robots': msg.robots,
                'timestamp': datetime.now()
            }
            
            # Update previous task IDs for completion detection
            for robot in msg.robots:
                robot_name = robot.name
                current_task_id = robot.task_id
                
                # If this is the first time we've seen this robot, initialize previous_task_id
                if robot_name not in self.previous_task_ids:
                    self.previous_task_ids[robot_name] = ''
                
                # Store current task_id for next comparison
                self.previous_task_ids[robot_name] = current_task_id
            
            logger.debug(f"Fleet {fleet_name} state updated with {len(msg.robots)} robots")
            
        except Exception as e:
            logger.error(f"Error processing fleet state: {e}")
    
    def update_mission_status(self):
        """
        Periodic mission status update - called every 1 second
        
        This function provides real-time mission monitoring and ensures
        synchronization between our mission data and RMF's actual state.
        """
        try:
            if not self.fleet_states:
                return  # No fleet data yet
            
            # Get all active RMF task IDs from fleet states
            active_rmf_tasks = self._get_active_rmf_tasks()
            robot_task_mapping = self._get_robot_task_mapping()
            
            logger.debug(f"🔄 Active RMF tasks: {len(active_rmf_tasks)}")
            logger.debug(f"🤖 Robot task mapping: {robot_task_mapping}")
            
            # Update mission states based on active tasks
            self._update_mission_states(active_rmf_tasks)
            
            # Assign available robots to unassigned missions
            self._assign_available_robots()
            
        except Exception as e:
            logger.error(f"🚨 Error in mission status update: {e}")
    
    def _get_active_rmf_tasks(self) -> set:
        """Get set of currently active RMF task IDs"""
        active_rmf_tasks = set()
        
        for fleet_name, fleet_data in self.fleet_states.items():
            for robot in fleet_data['robots']:
                if robot.task_id and robot.task_id != '':
                    active_rmf_tasks.add(robot.task_id)
        
        return active_rmf_tasks
    
    def _get_robot_task_mapping(self) -> dict:
        """Get mapping of robot names to their current task IDs"""
        robot_task_mapping = {}
        
        for fleet_name, fleet_data in self.fleet_states.items():
            for robot in fleet_data['robots']:
                if robot.task_id and robot.task_id != '':
                    robot_task_mapping[robot.name] = robot.task_id
        
        return robot_task_mapping
    
    def _update_mission_states(self, active_rmf_tasks: set):
        """Update mission states based on active RMF tasks"""
        for mission_id, mission_data in missions_db.items():
            mission_rmf_task_id = mission_data.get('rmf_task_id')
            current_state = mission_data.get('state')
            
            if mission_rmf_task_id:
                if mission_rmf_task_id in active_rmf_tasks:
                    # Task is active - sync with RMF
                    logger.debug(f"✅ Mission {mission_id} has active RMF task {mission_rmf_task_id}")
                    self._update_active_mission(mission_id, mission_data, mission_rmf_task_id)
                else:
                    # Task is not active - check completion
                    self._check_mission_completion(mission_id, mission_data)
            else:
                logger.warning(f"Mission {mission_id} has no RMF task ID")
    
    def _check_mission_completion(self, mission_id: int, mission_data: dict):
        """Check if a mission should be marked as complete"""
        mission_created = mission_data.get('created_at')
        if mission_created:
            time_since_creation = (datetime.now() - mission_created).total_seconds()
            
            if time_since_creation < 30:  # Less than 30 seconds old
                logger.debug(f"⏳ Mission {mission_id} is recent ({time_since_creation:.1f}s old) "
                            f"- RMF task might still be processing")
            else:
                logger.info(f"⏰ Mission {mission_id} task completed - marking as complete")
                self._mark_mission_complete(mission_id, mission_data)
    
    def _update_active_mission(self, mission_id: int, mission_data: dict, rmf_task_id: str):
        """
        Update an active mission with current robot assignment and status
        
        This function ensures that our mission data stays synchronized with RMF's
        actual robot assignments, preventing discrepancies between what we think
        is assigned and what RMF actually assigned.
        
        Args:
            mission_id: Internal mission identifier
            mission_data: Mission data dictionary
            rmf_task_id: RMF task identifier for tracking
        """
        try:
            # Find which robot RMF actually assigned to this task
            assigned_robot = self._find_robot_by_task_id(rmf_task_id)
            
            if assigned_robot:
                # Always update robot assignment to match RMF reality
                previous_assignment = mission_data.get('assigned_machine', 'Unknown')
                
                if previous_assignment != assigned_robot:
                    # Log the assignment correction for audit trail
                    self._log_assignment_change(
                        mission_id, previous_assignment, assigned_robot, rmf_task_id
                    )
                    
                    # Update assignment fields
                    mission_data['assigned_machine'] = assigned_robot
                    mission_data['assigned_machine_id'] = _get_robot_id(assigned_robot)
                    mission_data['rmf_assignment_confirmed'] = True
                    mission_data['last_assignment_update'] = datetime.now()
                    
                    # Add to assignment history
                    self._add_assignment_history_entry(
                        mission_data, 'corrected', previous_assignment, assigned_robot
                    )
                    
                    logger.info(f"✅ Mission {mission_id} robot assignment synchronized: "
                               f"'{previous_assignment}' → '{assigned_robot}' (RMF Task: {rmf_task_id})")
                else:
                    # Assignment is already correct, just update timestamp
                    mission_data['last_assignment_update'] = datetime.now()
                    logger.debug(f"Mission {mission_id} robot assignment already correct: {assigned_robot}")
                
                # Update mission state if needed
                self._update_mission_execution_state(mission_id, mission_data)
                
            else:
                # RMF task exists but no robot is assigned - this indicates a problem
                self._handle_orphaned_rmf_task(mission_id, mission_data, rmf_task_id)
                
        except Exception as e:
            logger.error(f"🚨 Error updating mission {mission_id} assignment: {e}")
            # Don't raise - we want to continue processing other missions
            self._add_assignment_history_entry(
                mission_data, 'error', 
                mission_data.get('assigned_machine', 'Unknown'), 
                f"Error: {str(e)}"
            )
    
    def _find_robot_by_task_id(self, rmf_task_id: str) -> Optional[str]:
        """
        Find which robot is assigned to a specific RMF task
        
        Args:
            rmf_task_id: RMF task identifier
            
        Returns:
            Robot name if found, None otherwise
        """
        if not self.fleet_states:
            return None
        
        for fleet_name, fleet_data in self.fleet_states.items():
            for robot in fleet_data['robots']:
                if robot.task_id == rmf_task_id:
                    return robot.name
        
        return None
    
    def _log_assignment_change(self, mission_id: int, old_robot: str, new_robot: str, rmf_task_id: str):
        """
        Log robot assignment changes for audit and debugging
        
        Args:
            mission_id: Internal mission identifier
            old_robot: Previous robot assignment
            new_robot: New robot assignment
            rmf_task_id: RMF task identifier
        """
        change_log = {
            'timestamp': datetime.now().isoformat(),
            'mission_id': mission_id,
            'old_robot': old_robot,
            'new_robot': new_robot,
            'rmf_task_id': rmf_task_id,
            'change_type': 'robot_assignment_sync',
            'source': 'rmf_fleet_state'
        }
        
        logger.info(f"🔄 Robot assignment change logged: {json.dumps(change_log, indent=2)}")
    
    def _add_assignment_history_entry(self, mission_data: dict, change_type: str, 
                                    old_value: str, new_value: str):
        """
        Add entry to mission assignment history
        
        Args:
            mission_data: Mission data dictionary
            change_type: Type of change (e.g., 'corrected', 'error', 'initial')
            old_value: Previous value
            new_value: New value
        """
        if 'assignment_history' not in mission_data:
            mission_data['assignment_history'] = []
        
        history_entry = {
            'timestamp': datetime.now().isoformat(),
            'change_type': change_type,
            'old_value': old_value,
            'new_value': new_value,
            'source': 'mission_tracker'
        }
        
        mission_data['assignment_history'].append(history_entry)
        
        # Keep only last 20 entries to prevent memory bloat
        if len(mission_data['assignment_history']) > 20:
            mission_data['assignment_history'] = mission_data['assignment_history'][-20:]
    
    def _update_mission_execution_state(self, mission_id: int, mission_data: dict):
        """
        Update mission execution state based on current robot assignment
        
        Args:
            mission_id: Internal mission identifier
            mission_data: Mission data dictionary
        """
        current_state = mission_data.get('state')
        
        if current_state != 'Executing':
            mission_data['state'] = 'Executing'
            mission_data['current_step_index'] = 0
            
            # Update step statuses
            if 'steps' in mission_data and len(mission_data['steps']) >= 2:
                mission_data['steps'][0]['step_status'] = 'DrivingToPickup'
                mission_data['steps'][1]['step_status'] = 'Generated'
            
            logger.info(f"🚀 Mission {mission_id} state updated to Executing "
                       f"(Robot: {mission_data.get('assigned_machine')})")
    
    def _handle_orphaned_rmf_task(self, mission_id: int, mission_data: dict, rmf_task_id: str):
        """
        Handle cases where RMF task exists but no robot is assigned
        
        This can happen during task transitions or if there's a timing issue
        between RMF task creation and robot assignment.
        
        Args:
            mission_id: Internal mission identifier
            mission_data: Mission data dictionary
            rmf_task_id: RMF task identifier
        """
        logger.warning(f"⚠️ Mission {mission_id} has orphaned RMF task {rmf_task_id} "
                       f"- no robot currently assigned")
        
        # Add to assignment history
        self._add_assignment_history_entry(
            mission_data, 'orphaned', 
            mission_data.get('assigned_machine', 'Unknown'), 
            'No robot assigned'
        )
        
        # Check if this is a recent task (might still be processing)
        mission_created = mission_data.get('created_at')
        if mission_created:
            time_since_creation = (datetime.now() - mission_created).total_seconds()
            if time_since_creation < 60:  # Less than 1 minute old
                logger.info(f"⏳ Mission {mission_id} is recent ({time_since_creation:.1f}s old) "
                           f"- RMF task assignment might still be processing")
            else:
                logger.warning(f"⏰ Mission {mission_id} is {time_since_creation:.1f}s old "
                              f"- orphaned task might indicate a problem")
    
    def _mark_mission_complete(self, mission_id: int, mission_data: dict):
        """Mark a mission as complete"""
        if mission_data.get('state') != 'Complete':
            mission_data['state'] = 'Complete'
            mission_data['current_step_index'] = 1
            mission_data['steps'][0]['step_status'] = 'Complete'
            mission_data['steps'][1]['step_status'] = 'Complete'
            logger.info(f"Mission {mission_id} marked as complete")
    
    def _assign_available_robots(self):
        """
        Assign available robots to unassigned missions
        
        This function provides initial robot assignments based on availability,
        but these assignments will be corrected by RMF sync when the actual
        robot is assigned by RMF.
        """
        try:
            # Get available robots from fleet states
            available_robots = self._get_available_robots()
            
            if not available_robots:
                logger.debug("No available robots for assignment")
                return
            
            # Get unassigned missions
            unassigned_missions = self._get_unassigned_missions()
            
            if not unassigned_missions:
                logger.debug("No unassigned missions for robot assignment")
                return
            
            # Assign available robots to missions
            self._process_robot_assignments(available_robots, unassigned_missions)
            
        except Exception as e:
            logger.error(f"🚨 Error in robot assignment process: {e}")
    
    def _get_available_robots(self) -> List[str]:
        """Get list of currently available robots"""
        available_robots = []
        
        if not self.fleet_states:
            return available_robots
        
        for fleet_name, fleet_data in self.fleet_states.items():
            for robot in fleet_data['robots']:
                if robot.task_id == '' or robot.task_id is None:
                    available_robots.append(robot.name)
        
        logger.debug(f"Found {len(available_robots)} available robots: {available_robots}")
        return available_robots
    
    def _get_unassigned_missions(self) -> List[tuple]:
        """Get list of missions that need robot assignment"""
        unassigned_missions = []
        
        for mission_id, mission_data in missions_db.items():
            if (mission_data.get('state') == 'Generated' and 
                mission_data.get('assigned_machine') == 'Unknown'):
                unassigned_missions.append((mission_id, mission_data))
        
        logger.debug(f"Found {len(unassigned_missions)} unassigned missions")
        return unassigned_missions
    
    def _process_robot_assignments(self, available_robots: List[str], 
                                  unassigned_missions: List[tuple]):
        """Process robot assignments for unassigned missions"""
        assigned_count = 0
        
        for mission_id, mission_data in unassigned_missions:
            if available_robots:
                # Get next available robot
                assigned_robot = available_robots.pop(0)
                
                # Make initial assignment (will be corrected by RMF sync)
                self._make_initial_assignment(mission_id, mission_data, assigned_robot)
                assigned_count += 1
                
                logger.info(f"📋 Mission {mission_id} initially assigned to {assigned_robot} "
                           f"(pending RMF confirmation)")
            else:
                logger.warning(f"⚠️ No more available robots for mission {mission_id}")
                break
        
        if assigned_count > 0:
            logger.info(f"✅ Initial robot assignments completed: {assigned_count} missions assigned")
    
    def _make_initial_assignment(self, mission_id: int, mission_data: dict, robot_name: str):
        """Make initial robot assignment for a mission"""
        # Store initial assignment
        mission_data['assigned_machine'] = robot_name
        mission_data['assigned_machine_id'] = _get_robot_id(robot_name)
        mission_data['state'] = 'Queued'
        mission_data['rmf_assignment_confirmed'] = False
        mission_data['last_assignment_update'] = datetime.now()
        
        # Add to assignment history
        self._add_assignment_history_entry(
            mission_data, 'initial', 'Unknown', robot_name
        )
        
        logger.debug(f"Initial assignment: Mission {mission_id} → {robot_name}")

class RMFTaskRequester(Node):
    """
    RMF Task Requester Node - Creates and manages individual RMF task requests
    
    This class creates a temporary node for each task request, following
    the pattern used in dispatch_patrol.py for consistency.
    """
    
    def __init__(self, patrol_places: List[str], rounds: int, external_id: str):
        """
        Initialize the task requester node
        
        Args:
            patrol_places: List of RMF place names for patrol (e.g., ["R11", "R4", "R7"])
            rounds: Number of patrol rounds to perform
            external_id: WCS mission ID for tracking
        """
        super().__init__('mission_api_task_requester')
        
        # Create future for async response handling
        self.response = asyncio.Future()
        
        # Generate unique request ID for this task
        self.request_id = f'patrol_{external_id}_{str(uuid.uuid4())[:8]}'
        
        # Configure QoS for reliable, transient communication
        transient_qos = QoSProfile(
            history=History.KEEP_LAST,
            depth=1,
            reliability=Reliability.RELIABLE,
            durability=Durability.TRANSIENT_LOCAL,
        )
        
        # Create publisher for sending task requests to RMF
        self.pub = self.create_publisher(
            ApiRequest, 'task_api_requests', transient_qos
        )
        
        # Create subscriber for receiving task responses from RMF
        self.sub = self.create_subscription(
            ApiResponse, 'task_api_responses', self.receive_response, 10
        )
        
        # Immediately create and publish the task request
        self.create_task_request(patrol_places, rounds)
    
    def create_task_request(self, patrol_places: List[str], rounds: int):
        """
        Create and publish RMF patrol task request message
        
        Args:
            patrol_places: List of RMF place names for patrol
            rounds: Number of patrol rounds to perform
        """
        msg = ApiRequest()
        msg.request_id = self.request_id
        
        # Use 0 for sim time (consistent with dispatch_patrol.py)
        start_time = 0
        
        # Construct the RMF patrol task request payload
        payload = {
            "type": "dispatch_task_request",
            "request": {
                "unix_millis_request_time": start_time,
                "unix_millis_earliest_start_time": start_time,
                "requester": "rmf_demos_tasks",
                "category": PATROL_CATEGORY,
                "description": {
                    "places": patrol_places,
                    "rounds": rounds
                }
            }
        }
        
        # Convert payload to JSON string and publish
        msg.json_msg = json.dumps(payload)
        
        logger.info(f"Publishing RMF patrol task request: {json.dumps(payload, indent=2)}")
        self.pub.publish(msg)
    
    def receive_response(self, response_msg: ApiResponse):
        """
        Handle incoming RMF task response
        
        Args:
            response_msg: RMF response message
        """
        # Only process response for our specific request
        if response_msg.request_id == self.request_id:
            try:
                # Parse JSON response from RMF
                response_data = json.loads(response_msg.json_msg)
                self.response.set_result(response_data)
                logger.info(f"Received RMF response: {response_data}")
            except Exception as e:
                logger.error(f"Error parsing RMF response: {e}")
                self.response.set_exception(e)

class RMFLoopTaskRequester(Node):
    """
    RMF Loop Task Requester Node - Creates and manages individual RMF loop task requests
    
    This class creates a temporary node for each loop task request, following
    the pattern used in dispatch_loop.py for consistency.
    """
    
    def __init__(self, start_place: str, finish_place: str, loops: int, priority: int, external_id: str):
        """
        Initialize the loop task requester node
        
        Args:
            start_place: Start waypoint name (e.g., "R11")
            finish_place: Finish waypoint name (e.g., "R7")
            loops: Number of loops to perform
            priority: Task priority level
            external_id: WCS mission ID for tracking
        """
        super().__init__('mission_api_loop_task_requester')
        
        # Create future for async response handling
        self.response = asyncio.Future()
        
        # Store task parameters
        self.start_place = start_place
        self.finish_place = finish_place
        self.loops = loops
        self.priority = priority
        self.external_id = external_id
        
        # Create service client for submitting loop tasks
        self.submit_task_srv = self.create_client(SubmitTask, '/submit_task')
        
        # Immediately create and submit the loop task request
        self.create_loop_task_request()
    
    def create_loop_task_request(self):
        """
        Create and submit RMF loop task request message
        
        This follows the same pattern as dispatch_loop.py
        """
        # Wait for service to be available
        if not self.submit_task_srv.wait_for_service(timeout_sec=3.0):
            self.get_logger().error('Dispatcher Node is not available')
            self.response.set_exception(Exception("Dispatcher service not available"))
            return
        
        # Create the DISPATCH LOOP task request message (NOT patrol)
        # This uses the same API as dispatch_loop.py
        req_msg = SubmitTask.Request()
        req_msg.description.task_type.type = TaskType.TYPE_LOOP
        
        # Set up loop parameters
        loop = Loop()
        loop.num_loops = self.loops
        loop.start_name = self.start_place
        loop.finish_name = self.finish_place
        req_msg.description.loop = loop
        
        # Set start time (use current time + 0 seconds for immediate execution)
        ros_start_time = self.get_clock().now().to_msg()
        ros_start_time.sec += 0  # Start immediately
        req_msg.description.start_time = ros_start_time
        
        # Set priority
        req_msg.description.priority.value = self.priority
        
        logger.info(f"Generated DISPATCH LOOP request: start={self.start_place}, finish={self.finish_place}, loops={self.loops}, priority={self.priority}")
        logger.info(f"Task Type: TYPE_LOOP (NOT patrol)")
        print(f"\nGenerated DISPATCH LOOP request: \n {req_msg}\n")
        
        # Submit the task asynchronously
        try:
            future = self.submit_task_srv.call_async(req_msg)
            
            # Set up a timer to check for response
            self.create_timer(0.1, lambda: self.check_response(future))
            
        except Exception as e:
            logger.error(f"Error submitting loop task: {e}")
            self.response.set_exception(e)
    
    def check_response(self, future):
        """Check if the service call future is done and handle response"""
        if future.done():
            try:
                response = future.result()
                if response is None:
                    logger.error('/submit_task srv call failed')
                    self.response.set_exception(Exception("Service call failed"))
                elif not response.success:
                    logger.error('Dispatcher node failed to accept task')
                    self.response.set_exception(Exception("Task rejected by dispatcher"))
                else:
                    logger.info(f'DISPATCH LOOP task successfully submitted with task_id: [{response.task_id}]')
                    # Return success response in the same format as patrol task
                    result = {
                        "success": True,
                        "state": {
                            "booking": {
                                "id": response.task_id
                            }
                        }
                    }
                    self.response.set_result(result)
            except Exception as e:
                logger.error(f'Error! Submit Srv failed: {e}')
                self.response.set_exception(e)

# =============================================================================
# GLOBAL MISSION TRACKER INSTANCE
# =============================================================================

# Global mission tracker instance (singleton pattern)
mission_tracker = None
background_task = None

def get_mission_tracker():
    """
    Get or create mission tracker instance
    
    Returns:
        MissionTracker: Singleton mission tracker instance
    """
    global mission_tracker
    if mission_tracker is None:
        try:
            # Ensure ROS 2 context is initialized
            if not ensure_ros_context():
                raise RuntimeError("Failed to initialize ROS 2 context")
            
            # Create mission tracker node
            mission_tracker = MissionTracker()
            logger.info("✅ Mission tracker created")
        
        except Exception as e:
            logger.error(f"Failed to create mission tracker: {e}")
            raise
    
    return mission_tracker

async def ensure_background_monitoring():
    """Ensure background monitoring is running, restart if needed"""
    global background_task
    
    # Check if background task is running
    if background_task is None or background_task.done():
        logger.warning("⚠️ Background monitoring is not running, restarting...")
        await start_background_monitoring()
        return True
    
    # Check if task has an exception (only if it's done and has an exception)
    if background_task.done() and background_task.exception():
        logger.error(f"🚨 Background task has exception: {background_task.exception()}")
        logger.info("🔄 Restarting background monitoring...")
        await start_background_monitoring()
        return True
    
    return False

async def start_background_monitoring():
    """Start background mission monitoring"""
    global background_task
    
    # Cancel existing task if running
    if background_task and not background_task.done():
        background_task.cancel()
        try:
            await background_task
        except asyncio.CancelledError:
            pass
        logger.info("✅ Existing background task cancelled")
    
    # Ensure mission tracker exists
    tracker = get_mission_tracker()
    
    # Start the ROS 2 node in the background
    background_task = asyncio.create_task(run_ros_node_with_restart(tracker))
    logger.info("✅ Background ROS 2 monitoring started")

async def run_ros_node_with_restart(node: Node):
    """Run ROS 2 node with automatic restart on failure"""
    restart_count = 0
    max_restarts = 5
    
    while restart_count < max_restarts:
        try:
            logger.info(f"🚀 Starting ROS 2 background task (attempt {restart_count + 1}/{max_restarts})")
            
            # Check if we need to reinitialize ROS 2 context
            if not is_ros_context_valid():
                logger.warning("🔄 ROS 2 context invalid, attempting to reinitialize...")
                try:
                    # Reset the global flag
                    global ros_context_initialized
                    ros_context_initialized = False
                    
                    # Try to reinitialize
                    if ensure_ros_context():
                        logger.info("✅ ROS 2 context reinitialized successfully")
                    else:
                        logger.error("❌ Failed to reinitialize ROS 2 context")
                        raise RuntimeError("ROS 2 context reinitialization failed")
                except Exception as e:
                    logger.error(f"🚨 ROS 2 context reinitialization failed: {e}")
                    restart_count += 1
                    if restart_count < max_restarts:
                        logger.info(f"🔄 Waiting 10 seconds before retry...")
                        await asyncio.sleep(10.0)
                        continue
                    else:
                        break
            
            await run_ros_node(node)
            
            # If we get here, the task completed normally
            logger.info("✅ ROS 2 background task completed normally")
            break
            
        except Exception as e:
            restart_count += 1
            logger.error(f"🚨 ROS 2 background task failed (attempt {restart_count}/{max_restarts}): {e}")
                        
            if restart_count < max_restarts:
                logger.info(f"🔄 Restarting ROS 2 background task in 5 seconds...")
                await asyncio.sleep(5.0)  # Wait before restarting
            else:
                logger.error(f"💥 Maximum restart attempts reached. ROS 2 monitoring stopped.")
                break

def ensure_ros_context():
    """Ensure ROS 2 context is initialized, but only once"""
    global ros_context_initialized
    
    if ros_context_initialized:
        logger.debug("✅ ROS 2 context already initialized")
        return True
    
    try:
        rclpy.init()
        ros_context_initialized = True
        logger.info("✅ ROS 2 context initialized successfully")
        return True
    except Exception as e:
        if "already initialized" in str(e):
            ros_context_initialized = True
            logger.info("✅ ROS 2 context already initialized")
            return True
        else:
            logger.error(f"Failed to initialize ROS 2: {e}")
            return False

def is_ros_context_valid():
    """Check if ROS 2 context is still valid"""
    try:
        # Try to create a simple node to test context validity
        test_node = rclpy.create_node('test_context')
        test_node.destroy_node()
        return True
    except Exception as e:
        error_msg = str(e)
        if "rclpy.init() has not been called" in error_msg:
            logger.warning("ROS 2 context not initialized")
            return False
        elif "rcl_shutdown already called" in error_msg:
            logger.warning("ROS 2 context already shut down")
            return False
        elif "Context.init() must only be called once" in error_msg:
            logger.warning("ROS 2 context initialization conflict")
            return False
        else:
            logger.warning(f"ROS 2 context validation error: {e}")
            return False

async def run_ros_node(node: Node):
    """Run ROS 2 node in background task"""
    try:
        logger.info("🚀 Starting ROS 2 node execution...")
        
        # Check if ROS 2 context is still valid
        if not is_ros_context_valid():
            logger.error("🚨 ROS 2 context is not valid, cannot start node")
            raise RuntimeError("ROS 2 context is not valid")
        
        # Create executor with proper error handling
        executor = rclpy.executors.SingleThreadedExecutor()
        executor.add_node(node)
        
        logger.info("✅ ROS 2 executor created and node added")
        
        # Start the mission tracker timer now that the node is running
        try:
            node.start_timer()
            logger.info("✅ Mission tracker timer started successfully")
        except Exception as e:
            logger.error(f"Failed to start mission tracker timer: {e}")
            raise
        
        # Spin the node continuously with proper error handling
        consecutive_errors = 0
        max_consecutive_errors = 5
        
        while True:
            try:
                # Check context validity before each spin
                if not is_ros_context_valid():
                    logger.error("🚨 ROS 2 context became invalid during execution")
                    break
                
                # Process pending ROS 2 messages
                executor.spin_once(timeout_sec=0.1)
                await asyncio.sleep(0.1)  # Small delay to prevent blocking
                
                # Reset error counter on successful spin
                consecutive_errors = 0
                
            except Exception as e:
                consecutive_errors += 1
                logger.error(f"Error in ROS 2 spin_once (attempt {consecutive_errors}/{max_consecutive_errors}): {e}")
                
                if consecutive_errors >= max_consecutive_errors:
                    logger.error(f"🚨 Too many consecutive errors, stopping ROS 2 node")
                    break
                
                await asyncio.sleep(1.0)  # Wait before retrying
                continue
                
    except Exception as e:
        logger.error(f"Critical error in ROS 2 background task: {e}")
        logger.error(f"Error type: {type(e).__name__}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        raise  # Re-raise to trigger restart
    finally:
        try:
            # Clean up executor
            if 'executor' in locals():
                executor.shutdown()
                logger.info("✅ ROS 2 executor shutdown completed")
        except Exception as cleanup_error:
            logger.warning(f"Warning during executor cleanup: {cleanup_error}")
        
        logger.info("🛑 ROS 2 background task stopped")

# =============================================================================
# MISSION STATUS UPDATE FUNCTION (Simplified)
# =============================================================================

def update_mission_status_from_fleet():
    """
    Update mission status from the latest fleet state data
    This function is now simplified since the MissionTracker handles updates automatically
    """
    # The MissionTracker now handles all updates automatically via timer
    # This function is kept for backward compatibility but does minimal work
    logger.debug("Mission status updates are now handled automatically by MissionTracker")

def debug_mission_states():
    """Debug function to show current mission and robot states"""
    logger.info("=== DEBUG: MISSION AND ROBOT STATES ===")
    
    # Show all missions
    for mission_id, mission_data in missions_db.items():
        logger.info(f"Mission {mission_id}: {mission_data.get('external_id')}")
        logger.info(f"  State: {mission_data.get('state')}")
        logger.info(f"  Robot: {mission_data.get('assigned_machine')}")
        logger.info(f"  RMF Task: {mission_data.get('rmf_task_id')}")
        logger.info(f"  RMF Confirmed: {mission_data.get('rmf_assignment_confirmed', False)}")
        logger.info(f"  Assignment History: {len(mission_data.get('assignment_history', []))} entries")
    
    # Show fleet state if available
    if mission_tracker and mission_tracker.fleet_states:
        for fleet_name, fleet_data in mission_tracker.fleet_states.items():
            logger.info(f"Fleet {fleet_name}:")
            for robot in fleet_data['robots']:
                logger.info(f"  Robot {robot.name}: task_id='{robot.task_id}', mode={robot.mode.mode}")
    else:
        logger.info("No fleet state data available")
    
    logger.info("=========================================")

def get_assignment_sync_status():
    """
    Get detailed assignment synchronization status for monitoring
    
    Returns:
        Dictionary containing sync status information
    """
    sync_status = {
        'timestamp': datetime.now().isoformat(),
        'total_missions': len(missions_db),
        'sync_summary': {
            'rmf_confirmed': 0,
            'pending_confirmation': 0,
            'assignment_errors': 0
        },
        'mission_details': {}
    }
    
    for mission_id, mission_data in missions_db.items():
        mission_sync_info = {
            'external_id': mission_data.get('external_id'),
            'current_robot': mission_data.get('assigned_machine'),
            'rmf_confirmed': mission_data.get('rmf_assignment_confirmed', False),
            'last_update': mission_data.get('last_assignment_update'),
            'assignment_history_count': len(mission_data.get('assignment_history', [])),
            'state': mission_data.get('state')
        }
        
        sync_status['mission_details'][mission_id] = mission_sync_info
        
        # Update summary counts
        if mission_sync_info['rmf_confirmed']:
            sync_status['sync_summary']['rmf_confirmed'] += 1
        else:
            sync_status['sync_summary']['pending_confirmation'] += 1
        
        # Check for assignment errors
        if any(entry.get('change_type') == 'error' 
               for entry in mission_data.get('assignment_history', [])):
            sync_status['sync_summary']['assignment_errors'] += 1
    
    return sync_status

def check_rmf_task_status():
    """Check the status of RMF tasks and robot assignments for debugging"""
    logger.info("🔍 Checking RMF task status...")
    
    if not mission_tracker or not mission_tracker.fleet_states:
        logger.warning("No fleet state data available")
        return {"error": "No fleet state data"}
    
    # Get current fleet state
    fleet_info = {}
    active_tasks = set()
    
    for fleet_name, fleet_data in mission_tracker.fleet_states.items():
        fleet_info[fleet_name] = {
            'robots': [],
            'active_tasks': []
        }
        
        for robot in fleet_data['robots']:
            robot_info = {
                'name': robot.name,
                'task_id': robot.task_id,
                'mode': robot.mode.mode,
                'available': robot.task_id == '' or robot.task_id is None
            }
            fleet_info[fleet_name]['robots'].append(robot_info)
            
            if robot.task_id and robot.task_id != '':
                active_tasks.add(robot.task_id)
                fleet_info[fleet_name]['active_tasks'].append(robot.task_id)
    
    # Check mission status
    mission_status = {}
    for mission_id, mission_data in missions_db.items():
        mission_status[mission_id] = {
            'external_id': mission_data.get('external_id'),
            'rmf_task_id': mission_data.get('rmf_task_id'),
            'state': mission_data.get('state'),
            'assigned_robot': mission_data.get('assigned_machine'),
            'created_at': mission_data.get('created_at'),
            'task_active': mission_data.get('rmf_task_id') in active_tasks if mission_data.get('rmf_task_id') else False
        }
    
    return {
        'fleet_info': fleet_info,
        'active_tasks': list(active_tasks),
        'mission_status': mission_status,
        'timestamp': datetime.now().isoformat()
    }

@app.get("/api/CheckRMFStatus")
async def check_rmf_status_endpoint(
    x_api_key: Optional[str] = Header(None, alias="Apikey")
):
    """
    Check RMF task status and robot assignments for debugging
    
    Requires valid API key for authentication via Apikey header
    
    Returns:
        dict: Current RMF system status
    """
    
    # 🔐 API KEY VALIDATION
    if not x_api_key:
        logger.warning("❌ API key missing in CheckRMFStatus request")
        raise HTTPException(
            status_code=401, 
            detail="API key required. Please provide Apikey header."
        )
    
    if x_api_key != WCS_API_KEY:
        logger.warning(f"❌ Invalid API key provided in CheckRMFStatus: {x_api_key}")
        raise HTTPException(
            status_code=401, 
            detail="Invalid API key. Access denied."
        )
    
    logger.info(f"✅ API key validated successfully for CheckRMFStatus request")
    try:
        return check_rmf_task_status()
    except Exception as e:
        logger.error(f"Error checking RMF status: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to check RMF status: {str(e)}")

@app.post("/api/RestartBackgroundTask")
async def restart_background_task_endpoint(
    x_api_key: Optional[str] = Header(None, alias="Apikey")
):
    """
    Manually restart the background ROS 2 monitoring task
    
    Requires valid API key for authentication via Apikey header
    
    Returns:
        dict: Restart operation result
    """
    
    # 🔐 API KEY VALIDATION
    if not x_api_key:
        logger.warning("❌ API key missing in RestartBackgroundTask request")
        raise HTTPException(
            status_code=401, 
            detail="API key required. Please provide Apikey header."
        )
    
    if x_api_key != WCS_API_KEY:
        logger.warning(f"❌ Invalid API key provided in RestartBackgroundTask: {x_api_key}")
        raise HTTPException(
            status_code=401, 
            detail="Invalid API key. Access denied."
        )
    
    logger.info(f"✅ API key validated successfully for RestartBackgroundTask request")
    try:
        await start_background_monitoring()
        
        return {
            "success": True,
            "message": "Background ROS 2 monitoring restarted",
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error restarting background task: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to restart background task: {str(e)}")

@app.get("/api/DebugStatus")
async def debug_status_endpoint(
    x_api_key: Optional[str] = Header(None, alias="Apikey")
):
    """
    Debug endpoint to get detailed system status for troubleshooting
    
    Requires valid API key for authentication via Apikey header
    
    Returns:
        dict: Detailed system status information
    """
    
    # 🔐 API KEY VALIDATION
    if not x_api_key:
        logger.warning("❌ API key missing in DebugStatus request")
        raise HTTPException(
            status_code=401, 
            detail="API key required. Please provide Apikey header."
        )
    
    if x_api_key != WCS_API_KEY:
        logger.warning(f"❌ Invalid API key provided in DebugStatus: {x_api_key}")
        raise HTTPException(
            status_code=401, 
            detail="Invalid API key. Access denied."
        )
    
    logger.info(f"✅ API key validated successfully for DebugStatus request")
    try:
        global background_task, mission_tracker, ros_context_initialized
        
        # Get detailed status
        status_info = {
            "timestamp": datetime.now().isoformat(),
            "ros_context": {
                "initialized": ros_context_initialized,
                "valid": is_ros_context_valid(),
                "can_create_node": False
            },
            "background_task": {
                "exists": background_task is not None,
                "status": "unknown"
            },
            "mission_tracker": {
                "exists": mission_tracker is not None,
                "status": "unknown"
            },
            "missions": {
                "total": len(missions_db),
                "details": {}
            }
        }
        
        # Test ROS 2 context
        try:
            if is_ros_context_valid():
                test_node = rclpy.create_node('debug_test')
                test_node.destroy_node()
                status_info["ros_context"]["can_create_node"] = True
        except Exception as e:
            status_info["ros_context"]["error"] = str(e)
        
        # Check background task
        if background_task:
            if background_task.done():
                if background_task.cancelled():
                    status_info["background_task"]["status"] = "cancelled"
                elif background_task.exception():
                    status_info["background_task"]["status"] = "failed"
                    status_info["background_task"]["error"] = str(background_task.exception())
                else:
                    status_info["background_task"]["status"] = "completed"
            else:
                status_info["background_task"]["status"] = "running"
        
        # Check mission tracker
        if mission_tracker:
            try:
                if hasattr(mission_tracker, 'get_name'):
                    status_info["mission_tracker"]["status"] = "active"
                    status_info["mission_tracker"]["name"] = mission_tracker.get_name()
                    status_info["mission_tracker"]["fleet_states_count"] = len(mission_tracker.fleet_states) if hasattr(mission_tracker, 'fleet_states') else 0
                else:
                    status_info["mission_tracker"]["status"] = "invalid"
            except Exception as e:
                status_info["mission_tracker"]["status"] = "error"
                status_info["mission_tracker"]["error"] = str(e)
        
        # Get mission details
        for mission_id, mission_data in missions_db.items():
            status_info["missions"]["details"][mission_id] = {
                "external_id": mission_data.get('external_id'),
                "state": mission_data.get('state'),
                "assigned_robot": mission_data.get('assigned_machine'),
                "rmf_task_id": mission_data.get('rmf_task_id'),
                "created_at": str(mission_data.get('created_at', 'unknown'))
            }
        
        return status_info
        
    except Exception as e:
        logger.error(f"Error in debug status endpoint: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get debug status: {str(e)}")

@app.get("/api/AssignmentSyncStatus")
async def assignment_sync_status_endpoint(
    x_api_key: Optional[str] = Header(None, alias="Apikey")
):
    """
    Get detailed assignment synchronization status for monitoring
    
    This endpoint shows how well your system is synchronized with RMF
    robot assignments, helping identify any sync issues.
    
    Requires valid API key for authentication via Apikey header
    
    Returns:
        dict: Assignment synchronization status information
    """
    
    # 🔐 API KEY VALIDATION
    if not x_api_key:
        logger.warning("❌ API key missing in AssignmentSyncStatus request")
        raise HTTPException(
            status_code=401, 
            detail="API key required. Please provide Apikey header."
        )
    
    if x_api_key != WCS_API_KEY:
        logger.warning(f"❌ Invalid API key provided in AssignmentSyncStatus: {x_api_key}")
        raise HTTPException(
            status_code=401, 
            detail="Invalid API key. Access denied."
        )
    
    logger.info(f"✅ API key validated successfully for AssignmentSyncStatus request")
    try:
        return get_assignment_sync_status()
    except Exception as e:
        logger.error(f"Error getting assignment sync status: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get assignment sync status: {str(e)}")

# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def _get_robot_id(robot_name: str) -> int:
    """
    Get numerical robot ID from robot name
    
    Args:
        robot_name: Robot name (e.g., "FourD_robot_3")
        
    Returns:
        Numerical robot ID (e.g., 3)
    """
    robot_id_map = {
        'FourD_robot_1': 1,
        'FourD_robot_2': 2,
        'FourD_robot_3': 3
    }
    return robot_id_map.get(robot_name, 0)

# Note: State mapping is now handled directly in update_mission_status_from_fleet()
# based on task assignment/completion detection from fleet states

# =============================================================================
# RMF TASK CREATION FUNCTION
# =============================================================================

async def create_rmf_loop_task(start_place: str, finish_place: str, loops: int, priority: int, external_id: str):
    """
    Create and send RMF loop task request using proper node lifecycle
    
    This function creates a temporary ROS 2 node to send a loop task request to RMF
    and waits for the response. It handles the complete lifecycle of the node
    including initialization, task creation, response waiting, and cleanup.
    
    Args:
        start_place: Start waypoint name (e.g., "R11")
        finish_place: Finish waypoint name (e.g., "R7")
        loops: Number of loops to perform
        priority: Task priority level
        external_id: WCS mission ID for tracking
        
    Returns:
        dict: RMF response data
        
    Raises:
        HTTPException: If task creation fails or times out
    """
    
    # Ensure ROS 2 context is initialized (but only once)
    if not ensure_ros_context():
        raise HTTPException(status_code=500, detail="Failed to initialize ROS 2 context")
    
    # Create loop task requester node for this specific request
    task_requester = RMFLoopTaskRequester(start_place, finish_place, loops, priority, external_id)
    
    try:
        # Wait for response with timeout (like dispatch_loop.py)
        # This blocks until we receive a response or timeout
        rclpy.spin_until_future_complete(
            task_requester, task_requester.response, timeout_sec=10.0
        )
        
        # Check if we got a response
        if task_requester.response.done():
            result = task_requester.response.result()
            logger.info(f"Loop task request completed: {result}")
            return result
        else:
            logger.error("Timeout waiting for RMF response")
            raise HTTPException(status_code=500, detail="RMF loop task request timeout")
            
    except Exception as e:
        logger.error(f"Error in RMF loop task request: {e}")
        raise HTTPException(status_code=500, detail=f"RMF loop task request failed: {str(e)}")
    finally:
        # Clean up: destroy node but DON'T shutdown ROS 2 context
        # This prevents the global context from being shut down
        task_requester.destroy_node()
        logger.info("✅ Loop task requester node destroyed (ROS 2 context preserved)")

# =============================================================================
# FASTAPI ENDPOINTS
# =============================================================================

@app.post("/api/TestAuth")
async def test_authentication(
    x_api_key: Optional[str] = Header(None, alias="Apikey")
):
    """
    Test endpoint to verify API key authentication
    
    Returns:
        dict: Authentication test result
    """
    
    # 🔐 API KEY VALIDATION
    if not x_api_key:
        logger.warning("❌ API key missing in test request")
        raise HTTPException(
            status_code=401, 
            detail="API key required. Please provide Apikey header."
        )
    
    if x_api_key != WCS_API_KEY:
        logger.warning(f"❌ Invalid API key provided in test: {x_api_key}")
        raise HTTPException(
            status_code=401, 
            detail="Invalid API key. Access denied."
        )
    
    logger.info(f"✅ API key validation test passed")
    
    return {
        "success": True,
        "message": "API key authentication successful",
        "timestamp": datetime.now().isoformat(),
        "api_key_provided": x_api_key,
        "api_key_valid": True
    }

@app.post("/api/MissionCreate", response_model=List[MissionResponse])
async def mission_create(
    request: Request,
    x_api_key: Optional[str] = Header(None, alias="Apikey")
):
    """
    Create a new loop mission from WCS request
    
    Requires valid API key for authentication via Apikey header
    """
    
    # 🔐 API KEY VALIDATION
    if not x_api_key:
        logger.warning("❌ API key missing in request")
        raise HTTPException(
            status_code=401, 
            detail="API key required. Please provide Apikey header."
        )
    
    if x_api_key != WCS_API_KEY:
        logger.warning(f"❌ Invalid API key provided: {x_api_key}")
        raise HTTPException(
            status_code=401, 
            detail="Invalid API key. Access denied."
        )
    
    logger.info(f"✅ API key validated successfully for request")
    
    global mission_counter
    
    try:
        # Parse the JSON request from WCS
        data = await request.json()
        logger.info(f"Received loop mission request: {json.dumps(data, indent=2)}")
        
        # Extract mission details from WCS request
        external_id = data.get("ExternalId", "")
        mission_name = data.get("Name", "")
        steps = data.get("Steps", [])
        options = data.get("Options", {})
        priority = options.get("Priority", 0)  # Extract priority from options
        loops = options.get("Rounds", 1)  # Use rounds as number of loops
        
        # Initialize variables to store pickup and dropoff locations
        pickup_place = None
        dropoff_place = None
        
        # Process each step to extract pickup and dropoff locations
        # WCS sends steps with StepType and AllowedTargets
        for step in steps:
            step_type = step.get("StepType", "")
            allowed_targets = step.get("AllowedTargets", [])
            
            # Extract place names directly from WCS targets
            # WCS sends place names like "R11", "R7" directly
            place_names = [target.get("Id") for target in allowed_targets if target.get("Id") is not None]
            
            # Extract pickup and dropoff locations
            if step_type == "Pickup" and place_names:
                pickup_place = place_names[0]  # Take first pickup location
                logger.info(f"Pickup step found with place: {pickup_place}")
            elif step_type == "Dropoff" and place_names:
                dropoff_place = place_names[0]  # Take first dropoff location
                logger.info(f"Dropoff step found with place: {dropoff_place}")
        
        # Print the extracted locations for debugging (as requested)
        print(f"=== LOOP MISSION LOCATIONS EXTRACTED ===")
        print(f"Mission ID: {external_id}")
        print(f"Mission Name: {mission_name}")
        print(f"Pickup Place: {pickup_place}")
        print(f"Dropoff Place: {dropoff_place}")
        print(f"Number of Loops: {loops}")
        print(f"Priority: {priority}")
        print(f"========================================")
        
        # Validate that we have both pickup and dropoff locations
        if not pickup_place or not dropoff_place:
            error_response = MissionResponse(
                ExternalId=external_id,
                InternalId=-1,
                Success=False,
                Description="Loop mission generation failed, need both pickup and dropoff locations",
                ReplyResult="StepTargetsNotValid"
            )
            logger.warning(f"Loop mission failed: {error_response.Description}")
            return [error_response]
        
        logger.info(f"Using DISPATCH LOOP task: {pickup_place} -> {dropoff_place} with {loops} loops and priority {priority}")
        
        # Create RMF loop task using the extracted pickup and dropoff locations
        try:
            rmf_response = await create_rmf_loop_task(pickup_place, dropoff_place, loops, priority, external_id)
            
            # Check if RMF task was successful
            if rmf_response.get('success', False):
                # Extract booking ID from RMF response for tracking
                booking_id = rmf_response.get('state', {}).get('booking', {}).get('id', 'unknown')
                
                # Create mission record with unique internal ID
                mission_id = mission_counter
                mission_counter += 1
                
                # Store mission data in our database
                # This data will be used by GetMissions endpoint for status tracking
                missions_db[mission_id] = {
                    'id': mission_id,
                    'external_id': external_id,
                    'name': mission_name,
                    'pickup_place': pickup_place,
                    'dropoff_place': dropoff_place,
                    'loops': loops,
                    'priority': priority,
                    'rmf_task_id': booking_id,
                    'state': 'Generated',  # Initial state
                    'assigned_machine': 'Unknown',  # Will be updated when robot is assigned
                    'assigned_machine_id': 0,
                    'current_step_index': 0,  # Start with first step
                    'created_at': datetime.now(),
                    # ✅ NEW: Assignment tracking fields
                    'assignment_history': [],  # Track all assignment changes
                    'rmf_assignment_confirmed': False,  # Whether RMF has confirmed assignment
                    'last_assignment_update': None,  # Timestamp of last assignment update
                    'steps': [
                        {
                            'step_type': 'Pickup',
                            'step_status': 'Generated',  # Initial step status
                            'current_target': f"Pick ({TARGET_ID_MAP.get(pickup_place, -1)})",
                            'current_target_id': TARGET_ID_MAP.get(pickup_place, -1),
                            'wait_target': '',
                            'target_shelf_id': -1,
                            'load_type': 'FP-1',
                            'load_type_id': 1,
                            'reserving_location': False
                        },
                        {
                            'step_type': 'Dropoff',
                            'step_status': 'Generated',  # Initial step status
                            'current_target': f"Drop ({TARGET_ID_MAP.get(dropoff_place, -1)})",
                            'current_target_id': TARGET_ID_MAP.get(dropoff_place, -1),
                            'wait_target': '',
                            'target_shelf_id': -1,
                            'load_type': 'FP-1',
                            'load_type_id': 1,
                            'reserving_location': False
                        }
                    ]
                }
                
                # Create success response for WCS
                success_response = MissionResponse(
                    ExternalId=external_id,
                    InternalId=mission_id,
                    Success=True,
                    Description=f"Loop mission created successfully. RMF Task ID: {booking_id}",
                    ReplyResult="Success"
                )
                
                logger.info(f"Loop mission created successfully: {external_id} -> RMF Task: {booking_id}")
                return [success_response]
            else:
                # RMF task creation failed
                error_response = MissionResponse(
                    ExternalId=external_id,
                    InternalId=-1,
                    Success=False,
                    Description="RMF loop task creation failed",
                    ReplyResult="TaskCreationFailed"
                )
                logger.warning(f"RMF loop task failed: {error_response.Description}")
                return [error_response]
                
        except HTTPException:
            # Re-raise HTTP exceptions (timeout, etc.)
            raise
        except Exception as e:
            # Handle other RMF task creation errors
            error_response = MissionResponse(
                ExternalId=external_id,
                InternalId=-1,
                Success=False,
                Description=f"RMF loop task creation error: {str(e)}",
                ReplyResult="TaskCreationError"
            )
            logger.error(f"RMF loop task error: {error_response.Description}")
            return [error_response]
        
    except json.JSONDecodeError as e:
        # Handle invalid JSON in request
        logger.error(f"Invalid JSON format: {e}")
        raise HTTPException(status_code=400, detail="Invalid JSON format")
    except Exception as e:
        # Handle any other unexpected errors
        logger.error(f"Unexpected error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/GetMissions", response_model=List[MissionData])
async def get_missions(
    x_api_key: Optional[str] = Header(None, alias="Apikey")
):
    """
    Get all missions with current status and progress
    
    This endpoint returns real-time status of all missions including:
    - Mission state (Generated, Executing, Complete, etc.)
    - Robot assignments
    - Step-by-step progress
    - Current target locations
    
    The status is updated automatically every second by the MissionTracker node.
    No manual status updates are needed.
    
    Requires valid API key for authentication via Apikey header
    
    Returns:
        List[MissionData]: List of all missions with current status
    """
    
    # 🔐 API KEY VALIDATION
    if not x_api_key:
        logger.warning(" API key missing in GetMissions request")
        raise HTTPException(
            status_code=401, 
            detail="API key required. Please provide Apikey header."
        )
    
    if x_api_key != WCS_API_KEY:
        logger.warning(f" Invalid API key provided in GetMissions: {x_api_key}")
        raise HTTPException(
            status_code=401, 
            detail="Invalid API key. Access denied."
        )
    
    logger.info(f" API key validated successfully for GetMissions request")
    
    # Get mission tracker to ensure it's initialized
    tracker = get_mission_tracker()
    
    # Ensure background monitoring is running
    await ensure_background_monitoring()
    
    # Debug: Show current missions in database
    logger.info("=== CURRENT MISSIONS IN DATABASE ===")
    for mission_id, mission_data in missions_db.items():
        logger.info(f"Mission {mission_id}: {mission_data.get('external_id')} -> RMF Task: {mission_data.get('rmf_task_id')} -> State: {mission_data.get('state')} -> Robot: {mission_data.get('assigned_machine')}")
    logger.info("===================================")
    
    # Mission status is now updated automatically by MissionTracker every second
    # No need to call update_mission_status_from_fleet() manually
    
    # Debug: Show detailed mission and robot states
    debug_mission_states()
    
    # Debug: Show missions after status update
    logger.info("=== MISSIONS AFTER STATUS UPDATE ===")
    for mission_id, mission_data in missions_db.items():
        logger.info(f"Mission {mission_id}: {mission_data.get('external_id')} -> RMF Task: {mission_data.get('rmf_task_id')} -> State: {mission_data.get('state')} -> Robot: {mission_data.get('assigned_machine')}")
    logger.info("===================================")
    
    # Convert internal mission data to WCS response format
    # The MissionTracker has already updated the missions_db automatically
    missions_response = []
    for mission_id, mission_data in missions_db.items():
        # Create StepData objects for each step
        steps_data = []
        for step in mission_data['steps']:
            step_data = StepData(
                StepType=step['step_type'],
                StepStatus=step['step_status'],
                CurrentTarget=step['current_target'],
                CurrentTargetId=step['current_target_id'],
                WaitTarget=step['wait_target'],
                TargetShelfId=step['target_shelf_id'],
                LoadType=step['load_type'],
                LoadTypeId=step['load_type_id'],
                ReservingLocation=step['reserving_location']
            )
            steps_data.append(step_data)
        
        # For loop missions, determine the final target (dropoff location)
        dropoff_place = mission_data.get('dropoff_place', '')
        final_target = "Loop Complete"
        final_target_id = -1
        
        if dropoff_place:
            # Use dropoff location as final target
            final_target = f"Drop ({TARGET_ID_MAP.get(dropoff_place, -1)})"
            final_target_id = TARGET_ID_MAP.get(dropoff_place, -1)
        
        # Create MissionData object for WCS response
        mission_response = MissionData(
            Id=mission_data['id'],
            MissionType="Mission",
            ExternalId=mission_data['external_id'],
            Name=mission_data['name'],
            State=mission_data['state'],
            AssignedMachine=mission_data['assigned_machine'],
            AssignedMachineId=mission_data.get('assigned_machine_id', 1),
            CurrentStepIndex=mission_data['current_step_index'],
            FinalTarget=final_target,
            FinalTargetId=final_target_id,
            Steps=steps_data
        )
        
        missions_response.append(mission_response)
    
    logger.info(f"Returning {len(missions_response)} missions")
    return missions_response

@app.get("/")
async def root():
    """
    Root endpoint - provides basic API information
    
    Returns:
        dict: API information and available endpoints
    """
    return {
        "message": "RMF Loop Mission API is running", 
        "endpoints": [
            "/api/TestAuth",
            "/api/MissionCreate", 
            "/api/GetMissions", 
            "/api/CheckRMFStatus", 
            "/api/RestartBackgroundTask",
            "/api/DebugStatus",
            "/api/AssignmentSyncStatus"
        ],
        "mission_type": "Loop",
        "features": [
            "Real-time mission tracking",
            "Professional robot assignment sync with RMF",
            "Assignment history tracking",
            "Automatic discrepancy resolution",
            "Loop tasks with pickup/dropoff locations",
            "Priority support for tasks"
        ]
    }

@app.get("/health")
async def health_check():
    """
    Health check endpoint for monitoring
    
    Returns:
        dict: API health status and timestamp
    """
    global background_task, mission_tracker, ros_context_initialized
    
    # Check background task status
    background_status = "unknown"
    if background_task:
        if background_task.done():
            if background_task.cancelled():
                background_status = "cancelled"
            elif background_task.exception():
                background_status = f"failed: {background_task.exception()}"
            else:
                background_status = "completed"
        else:
            background_status = "running"
    
    # Check mission tracker status
    tracker_status = "unknown"
    if mission_tracker:
        try:
            # Check if node is still valid
            if hasattr(mission_tracker, 'get_name'):
                tracker_status = "active"
            else:
                tracker_status = "invalid"
        except Exception as e:
            tracker_status = f"error: {e}"
    
    # Check fleet state data
    fleet_data_status = "unknown"
    if mission_tracker and hasattr(mission_tracker, 'fleet_states'):
        fleet_count = len(mission_tracker.fleet_states)
        if fleet_count > 0:
            fleet_data_status = f"active ({fleet_count} fleets)"
        else:
            fleet_data_status = "no data"
    
    # Check ROS 2 context status
    ros_context_status = "unknown"
    try:
        if is_ros_context_valid():
            ros_context_status = "valid"
        else:
            ros_context_status = "invalid"
    except Exception as e:
        ros_context_status = f"error: {e}"
    
    # Check missions database
    missions_count = len(missions_db)
    active_missions = sum(1 for m in missions_db.values() if m.get('state') in ['Generated', 'Executing', 'Queued'])
    
    return {
        "status": "healthy" if background_status == "running" and ros_context_status == "valid" else "degraded",
        "timestamp": datetime.now().isoformat(),
        "api_type": "RMF Loop Mission API",
        "authentication": {
            "api_key_required": True,
            "api_key_header": API_KEY_HEADER,
            "api_key_configured": bool(WCS_API_KEY)
        },
        "background_task": background_status,
        "mission_tracker": tracker_status,
        "fleet_data": fleet_data_status,
        "ros_context": {
            "status": ros_context_status,
            "initialized": ros_context_initialized
        },
        "missions": {
            "total": missions_count,
            "active": active_missions
        }
    }

# =============================================================================
# MAIN EXECUTION (for direct script execution)
# =============================================================================

if __name__ == "__main__":
    # Allow running the script directly for testing
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=1234)
