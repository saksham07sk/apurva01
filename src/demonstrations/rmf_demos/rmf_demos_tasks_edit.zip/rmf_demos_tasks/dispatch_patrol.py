#!/usr/bin/env python3

# Copyright 2022 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import sys
import uuid
import argparse
import json
import asyncio

import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.qos import qos_profile_system_default
from rclpy.qos import QoSProfile
from rclpy.qos import QoSHistoryPolicy as History
from rclpy.qos import QoSDurabilityPolicy as Durability
from rclpy.qos import QoSReliabilityPolicy as Reliability

from rmf_task_msgs.msg import ApiRequest, ApiResponse
from std_msgs.msg import String


###############################################################################

class TaskRequester(Node):

    def __init__(self, argv=sys.argv):
        super().__init__('task_requester')
        parser = argparse.ArgumentParser()
        parser.add_argument('-p', '--places', required=False, nargs='+',
                            type=str, help='Places to patrol through')
        parser.add_argument('-n', '--rounds',
                            help='Number of loops to perform',
                            type=int, default=1)
        parser.add_argument('-F', '--fleet', type=str,
                            help='Fleet name, should define tgt with robot')
        parser.add_argument('-R', '--robot', type=str,
                            help='Robot name, should define tgt with fleet')
        parser.add_argument('-st', '--start_time',
                            help='Start time from now in secs, default: 0',
                            type=int, default=0)
        parser.add_argument('-pt', '--priority',
                            help='Priority value for this request',
                            type=int, default=0)
        parser.add_argument("--use_sim_time", action="store_true",
                            help='Use sim time, default: false')

        self.args = parser.parse_args(argv[1:])
        self.response = asyncio.Future()
        self.patrol_points_received = False
        self.patrol_places = self.args.places
        self._done = False

        # If places are not provided, subscribe to /patrol_points
        if not self.patrol_places:
            self.get_logger().info('No patrol places provided via command line. Waiting for /patrol_points message...')
            self.create_subscription(String, '/patrol_points', self.patrol_points_callback, 10)
        else:
            self.dispatch_patrol_task()

    def patrol_points_callback(self, msg):
        if self.patrol_points_received:
            return  # Only handle the first message
        points = msg.data.split(',')
        if len(points) < 2:
            self.get_logger().error('Received patrol points message with less than 2 locations.')
            return
        self.patrol_places = points
        self.patrol_points_received = True
        self.get_logger().info(f'Received patrol points: {self.patrol_places}')
        self.dispatch_patrol_task()

    def dispatch_patrol_task(self):
        transient_qos = QoSProfile(
            history=History.KEEP_LAST,
            depth=1,
            reliability=Reliability.RELIABLE,
            durability=Durability.TRANSIENT_LOCAL)
        self.pub = self.create_publisher(
          ApiRequest, 'task_api_requests', transient_qos
        )
        # enable ros sim time
        if self.args.use_sim_time:
            self.get_logger().info("Using Sim Time")
            param = Parameter("use_sim_time", Parameter.Type.BOOL, True)
            self.set_parameters([param])
        msg = ApiRequest()
        msg.request_id = "patrol_" + str(uuid.uuid4())
        payload = {}
        if self.args.robot and self.args.fleet:
            self.get_logger().info("Using 'robot_task_request'")
            payload["type"] = "robot_task_request"
            payload["robot"] = self.args.robot
            payload["fleet"] = self.args.fleet
        else:
            self.get_logger().info("Using 'dispatch_task_request'")
            payload["type"] = "dispatch_task_request"
        request = {}
        now = self.get_clock().now().to_msg()
        now.sec = now.sec + self.args.start_time
        start_time = now.sec * 1000 + round(now.nanosec/10**6)
        request["unix_millis_earliest_start_time"] = start_time
        request["category"] = "patrol"
        description = {
            'places': self.patrol_places,
            'rounds': self.args.rounds
        }
        request["description"] = description
        payload["request"] = request
        msg.json_msg = json.dumps(payload)
        def receive_response(response_msg: ApiResponse):
            if response_msg.request_id == msg.request_id:
                self.response.set_result(json.loads(response_msg.json_msg))
                self._done = True
        transient_qos.depth = 10
        self.sub = self.create_subscription(
            ApiResponse, 'task_api_responses', receive_response, transient_qos
        )
        print(f"Json msg payload: \n{json.dumps(payload, indent=2)}")
        self.pub.publish(msg)


###############################################################################


def main(argv=sys.argv):
    rclpy.init(args=sys.argv)
    args_without_ros = rclpy.utilities.remove_ros_args(sys.argv)
    task_requester = TaskRequester(args_without_ros)
    # If patrol points are provided, spin until response or timeout
    # If not, spin until patrol points are received, then until response or timeout
    while rclpy.ok() and not task_requester._done:
        rclpy.spin_once(task_requester, timeout_sec=0.1)
    if task_requester.response.done():
        print(f'Got response:\n{task_requester.response.result()}')
    else:
        print('Did not get a response')
    rclpy.shutdown()


if __name__ == '__main__':
    main(sys.argv)
