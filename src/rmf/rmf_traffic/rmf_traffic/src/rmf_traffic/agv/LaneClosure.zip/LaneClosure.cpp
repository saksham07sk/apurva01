/*
 * Copyright (C) 2021 Open Source Robotics Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
*/

// Include the header file that declares the LaneClosure class interface
#include <rmf_traffic/agv/LaneClosure.hpp>
// Include unordered_map for efficient hash-based storage of bitfields
#include <unordered_map>
#include <iostream>
// Enter the RMF traffic namespace
namespace rmf_traffic {
// Enter the AGV (Automated Guided Vehicle) sub-namespace
namespace agv {

//==============================================================================
// Private implementation class that handles the actual data storage and operations
// This uses the PIMPL (Pointer to Implementation) pattern for encapsulation
class LaneClosure::Implementation
{
public:

  // Check if a specific lane (by index) is marked as closed
  // This is the core method that route planners call to avoid closed lanes
  bool contains(std::size_t value) const
  {
    std::cout << "[LaneClosure::Implementation::contains] 🔍 Checking if lane " << value << " is closed" << std::endl;
    
    // Assert that we're on a 64-bit system (each bitfield stores 64 lane states)
    assert(field_size == 64);
    
    // Calculate which bitfield bucket this lane index belongs to
    // For lane 100: key = 100/64 = 1 (second bucket)
    const std::size_t key = _get_key(value);
    std::cout << "[LaneClosure::Implementation::contains]  Lane " << value << " belongs to bucket " << key << std::endl;
    
    // Look up the bitfield bucket in our hash map
    const auto bucket_it = _bitfields.find(key);
    
    // If bucket doesn't exist, the lane is definitely open (not closed)
    if (bucket_it == _bitfields.end())
    {
      std::cout << "[LaneClosure::Implementation::contains] ✅ Lane " << value << " is OPEN (no bucket found)" << std::endl;
      return false;
    }

    // Calculate which specific bit within the bucket represents this lane
    // For lane 100: bit = 1 << (100 % 64) = 1 << 36
    const std::size_t bit = _get_bit(value);
    std::cout << "[LaneClosure::Implementation::contains] 🔢 Lane " << value << " bit position: " << bit << std::endl;
    
    // Get the actual bitfield value from the bucket
    const std::size_t bitfield = bucket_it->second;
    std::cout << "[LaneClosure::Implementation::contains] 📋 Bucket " << key << " bitfield: " << bitfield << std::endl;
    
    // Use bitwise AND to check if the specific bit is set
    // If bit is set, lane is closed; if not set, lane is open
    bool is_closed = static_cast<bool>(bitfield & bit);
    std::cout << "[LaneClosure::Implementation::contains] " << (is_closed ? "❌ CLOSED" : "✅ OPEN") << " Lane " << value << std::endl;
    return is_closed;
  }

  // Mark a lane as closed by setting its corresponding bit
  // This is called when obstacles are detected or lanes need to be blocked
  void insert(std::size_t value)
  {
    std::cout << "[LaneClosure::Implementation::insert] 🔒 Inserting lane " << value << " as closed" << std::endl;
    
    // Calculate which bitfield bucket and bit position for this lane
    const std::size_t key = _get_key(value);
    const std::size_t bit = _get_bit(value);
    std::cout << "[LaneClosure::Implementation::insert] 📊 Lane " << value << " -> bucket " << key << ", bit " << bit << std::endl;

    // Try to insert a new bitfield bucket with just this bit set
    const auto insertion = _bitfields.insert({key, bit});
    std::cout << "[LaneClosure::Implementation::insert] 🔄 Insertion result: " << (insertion.second ? "NEW bucket" : "EXISTING bucket") << std::endl;
    
    // Check if this was a new bucket (didn't exist before)
    if (insertion.second)
    {
      std::cout << "[LaneClosure::Implementation::insert] ✨ Created new bucket " << key << " with bit " << bit << std::endl;
      // The bitfield did not exist before, so now it has been inserted with
      // the desired bit. We will need to recalculate the hash. After that, we
      // can return.
      _recalculate_hash();
      std::cout << "[LaneClosure::Implementation::insert] 🔐 Recalculated hash: " << _hash << std::endl;
      return;
    }

    // Bucket already exists, get reference to the existing bitfield
    std::size_t& bitfield = insertion.first->second;
    std::cout << "[LaneClosure::Implementation::insert]  Existing bucket " << key << " bitfield: " << bitfield << std::endl;
    
    // Check if this specific bit is already set (lane already closed)
    if (static_cast<bool>(bitfield & bit))
    {
      std::cout << "[LaneClosure::Implementation::insert] ⚠️ Lane " << value << " already closed, no change needed" << std::endl;
      // The map already contained this value, so we do not need to insert it
      // or recalculate the hash.
      return;
    }

    // Set the bit using bitwise OR (lane is now closed)
    bitfield |= bit;
    std::cout << "[LaneClosure::Implementation::insert] 🔒 Set bit for lane " << value << ", new bitfield: " << bitfield << std::endl;
    
    // Recalculate hash since we modified the bitfield
    _recalculate_hash();
    std::cout << "[LaneClosure::Implementation::insert]  Recalculated hash: " << _hash << std::endl;
  }

  // Mark a lane as open by clearing its corresponding bit
  // This is called when obstacles are cleared or lanes are reopened
  void erase(std::size_t value)
  {
    std::cout << "[LaneClosure::Implementation::erase] 🔓 Erasing lane " << value << " (opening it)" << std::endl;
    
    // Calculate which bitfield bucket this lane belongs to
    const std::size_t key = _get_key(value);
    std::cout << "[LaneClosure::Implementation::erase]  Lane " << value << " belongs to bucket " << key << std::endl;
    
    // Look up the bitfield bucket
    const auto bucket_it = _bitfields.find(key);
    
    // If bucket doesn't exist, lane is already open (nothing to do)
    if (bucket_it == _bitfields.end())
    {
      std::cout << "[LaneClosure::Implementation::erase] ✅ Lane " << value << " already open (no bucket found)" << std::endl;
      // There was no bitfield for this value, so it is not in the map anyway.
      // We can simply return here.
      return;
    }

    // Calculate which specific bit represents this lane
    const std::size_t bit = _get_bit(value);
    std::cout << "[LaneClosure::Implementation::erase] 🔢 Lane " << value << " bit position: " << bit << std::endl;
    
    // Get reference to the bitfield
    std::size_t& bitfield = bucket_it->second;
    std::cout << "[LaneClosure::Implementation::erase] 📋 Current bitfield: " << bitfield << std::endl;
    
    // Check if the bit is currently set (lane is closed)
    if (!static_cast<bool>(bitfield & bit))
    {
      std::cout << "[LaneClosure::Implementation::erase] ⚠️ Lane " << value << " already open, no change needed" << std::endl;
      // This bit was not active in the bitfield, so we do not need to do
      // anything.
      return;
    }

    // Clear the bit using bitwise AND with NOT (lane is now open)
    bitfield &= ~bit;
    std::cout << "[LaneClosure::Implementation::erase]  Cleared bit for lane " << value << ", new bitfield: " << bitfield << std::endl;
    
    // Recalculate hash since we modified the bitfield
    _recalculate_hash();
    std::cout << "[LaneClosure::Implementation::erase]  Recalculated hash: " << _hash << std::endl;
  }

  // Return the current hash value for this LaneClosure state
  // Used for efficient comparison and caching in route planning
  std::size_t hash() const
  {
    std::cout << "[LaneClosure::Implementation::hash]  Returning hash: " << _hash << std::endl;
    return _hash;
  }

  // Compare two LaneClosure objects for equality
  // Used to check if lane closure states are identical
  bool operator==(const Implementation& other) const
  {
    std::cout << "[LaneClosure::Implementation::operator==] ⚖️ Comparing LaneClosure implementations" << std::endl;
    bool equal = _bitfields == other._bitfields;
    std::cout << "[LaneClosure::Implementation::operator==] " << (equal ? "✅ EQUAL" : "❌ NOT EQUAL") << std::endl;
    return equal;
  }

private:

  // Hash map storing bitfields: key = bucket index, value = 64-bit bitfield
  // Each bitfield can track 64 lanes (on 64-bit systems)
  std::unordered_map<std::size_t, std::size_t> _bitfields;
  
  // Cached hash value for fast comparison and lookup
  std::size_t _hash = 0;

  // Number of bits per bitfield (64 on 64-bit systems, 32 on 32-bit systems)
  static constexpr std::size_t field_size = sizeof(std::size_t)*8;

  // Recalculate the hash value by combining all bitfields
  // This is called whenever the bitfields are modified
  void _recalculate_hash()
  {
    std::cout << "[LaneClosure::Implementation::_recalculate_hash] 🔄 Recalculating hash from " << _hash;
    _hash = 0;
    // Iterate through all bitfield buckets
    for (const auto& [_, bitfield] : _bitfields)
      // Use bitwise OR to combine all bitfields into a single hash
      _hash |= bitfield;
    std::cout << " to " << _hash << std::endl;
  }

  // Calculate which bitfield bucket a lane index belongs to
  // For lane 100: returns 100/64 = 1 (second bucket)
  std::size_t _get_key(const std::size_t value) const
  {
    std::size_t key = value/field_size;
    std::cout << "[LaneClosure::Implementation::_get_key] 🔑 Lane " << value << " -> key " << key << std::endl;
    return key;
  }

  // Calculate which specific bit within a bucket represents a lane
  // For lane 100: returns 1 << (100 % 64) = 1 << 36
  std::size_t _get_bit(const std::size_t value) const
  {
    // Calculate the bit position within the 64-bit field
    const std::size_t shift = value % field_size;
    // Create a bitmask with only this bit set
    std::size_t bit = std::size_t(1) << shift;
    std::cout << "[LaneClosure::Implementation::_get_bit] 🔢 Lane " << value << " -> bit " << bit << " (shift " << shift << ")" << std::endl;
    return bit;
  }
};

//==============================================================================
// Default constructor - creates an empty LaneClosure with all lanes open
// This is called when a new LaneClosure object is created
LaneClosure::LaneClosure()
: _pimpl(rmf_utils::make_impl<Implementation>())  // Create the private implementation
{
  std::cout << "[LaneClosure::LaneClosure] ️ Constructor called - creating new LaneClosure" << std::endl;
  // Do nothing - all lanes are open by default
}

//==============================================================================
// Check if a specific lane is open (available for use)
// This is the method that route planners call to check lane availability
bool LaneClosure::is_open(const std::size_t lane) const
{
  std::cout << "[LaneClosure::is_open] 🔍 Checking if lane " << lane << " is open" << std::endl;
  // A lane is open if it's NOT closed
  bool open = !is_closed(lane);
  std::cout << "[LaneClosure::is_open] " << (open ? "✅ OPEN" : "❌ CLOSED") << " Lane " << lane << std::endl;
  return open;
}

//==============================================================================
// Check if a specific lane is closed (blocked/unavailable)
// This is the core method used by route planning algorithms to avoid closed lanes
bool LaneClosure::is_closed(const std::size_t lane) const
{
  std::cout << "[LaneClosure::is_closed]  Checking if lane " << lane << " is closed" << std::endl;
  
  // Delegate to the implementation's contains method
  bool closed = _pimpl->contains(lane);
  std::cout << "[LaneClosure::is_closed] " << (closed ? "❌ CLOSED" : "✅ OPEN") << " Lane " << lane << std::endl;
  return closed;
}

//==============================================================================
// Mark a lane as open (available for use)
// This is called when obstacles are cleared or lanes are reopened
LaneClosure& LaneClosure::open(const std::size_t lane)
{
  std::cout << "[LaneClosure::open]  Opening lane " << lane << std::endl;
  
  // Remove the lane from the closed lanes set
  _pimpl->erase(lane);
  
  std::cout << "[LaneClosure::open] ✅ Lane " << lane << " opened successfully" << std::endl;
  // Return reference to self for method chaining
  return *this;
}

//==============================================================================
// Mark a lane as closed (blocked/unavailable)
// This is called when obstacles are detected or lanes need to be blocked
LaneClosure& LaneClosure::close(std::size_t lane)
{
  std::cout << "[LaneClosure::close]  Closing lane " << lane << std::endl;
  
  // Add the lane to the closed lanes set
  _pimpl->insert(lane);
  
  std::cout << "[LaneClosure::close] ✅ Lane " << lane << " closed successfully" << std::endl;
  // Return reference to self for method chaining
  return *this;
}

//==============================================================================
// Get the hash value for this LaneClosure state
// Used for efficient comparison and caching in route planning systems
std::size_t LaneClosure::hash() const
{
  std::cout << "[LaneClosure::hash] 🔐 Getting hash value" << std::endl;
  // Delegate to the implementation's hash method
  std::size_t hash_value = _pimpl->hash();
  std::cout << "[LaneClosure::hash] 🔐 Hash value: " << hash_value << std::endl;
  return hash_value;
}

//==============================================================================
// Compare two LaneClosure objects for equality
// Used to check if two lane closure states are identical
bool LaneClosure::operator==(const LaneClosure& other) const
{
  std::cout << "[LaneClosure::operator==] ⚖️ Comparing LaneClosure objects" << std::endl;
  // Compare the underlying implementations
  bool equal = *_pimpl == *other._pimpl;
  std::cout << "[LaneClosure::operator==] " << (equal ? "✅ EQUAL" : "❌ NOT EQUAL") << std::endl;
  return equal;
}

// End of AGV namespace
} // namespace agv
// End of RMF traffic namespace
} // namespace rmf_traffic
